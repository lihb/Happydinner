package it.moondroid.coverflow.components.ui.containers.interfaces;


public interface IRemoveFromAdapter{
	void removeItemFromAdapter(int position);
}
